package com.projetIntegration.services;

import com.projetIntegration.entities.AppUser;
import com.projetIntegration.entities.Role;
import com.projetIntegration.repository.PersonneRepository;
import com.projetIntegration.repository.RoleRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.Arrays;

@Service
@Transactional
@AllArgsConstructor
@Data
public class AccountServiceImpl implements AccountService {

    private PersonneRepository personneRepository;
    private RoleRepository roleRepository;
    private PasswordEncoder passwordEncoder;

    @Override
    public AppUser addNewUser(String username, String pwd, String confirmpwd, Integer ncin, String nom) {
       AppUser personne=personneRepository.findByUsername(username);
        if (personne!=null) throw new RuntimeException("this user alredy exist");
        if (!pwd.equals(confirmpwd)) throw new RuntimeException("Password not match");
            personne= AppUser.builder()
                    .username(username)
                    .pwd(passwordEncoder.encode(pwd))
                    .ncin(ncin)
                    .nom(nom)
                    .build();
            AppUser savedper = personneRepository.save(personne);
        return savedper;
    }

    @Override
    public Role addNewRole(String role) {
        Role personRole = roleRepository.findById(role).orElse(null);
        if (personRole!=null) throw new RuntimeException("this role already exist");
        personRole=Role.builder()
                .role(role)
                .build();

        return roleRepository.save(personRole);
    }

    @Override
    public void AddRoleToPerson(String username, String role) {
            AppUser personne=personneRepository.findByUsername(username);
            Role role1=roleRepository.findById(role).get();
            personne.getRoles().add(role1);
    }

    @Override
    public void removeRoleFromPErson(String username, String role) {
        AppUser personne=personneRepository.findByUsername(username);
        Role role1=roleRepository.findById(role).get();
        personne.getRoles().remove(role1);
    }

    @Override
    public AppUser loadUserByUsername(String username) {

        return personneRepository.findByUsername(username);
    }

    @Override
    public void saveUser(AppUser duser) {
        AppUser user = new AppUser();
        user.setNom(user.getNom());
        user.setUsername(user.getUsername());
        user.setNcin(user.getNcin());
        //encrypt the password once we integrate spring security
        //user.setPassword(userDto.getPassword());
        user.setPwd(passwordEncoder.encode(user.getPwd()));
        Role role = roleRepository.findByRole("STUDENT");
        if(role == null){
            role = checkRoleExist();
        }
        user.setRoles(Arrays.asList(role));
        personneRepository.save(user);
    }
    private Role checkRoleExist() {
        Role role1 = new Role();
        role1.setRole("STUDENT");
        return roleRepository.save(role1);
    }

}
