package com.projetIntegration.services;

import com.projetIntegration.entities.AppUser;
import com.projetIntegration.entities.Role;

public interface AccountService {
    AppUser addNewUser(String username, String pwd, String confirmpwd, Integer ncin, String nom);
    Role addNewRole(String role);
    void AddRoleToPerson(String username, String role);
    void removeRoleFromPErson(String username , String role);
    AppUser loadUserByUsername(String username);

    void saveUser(AppUser user);

}
