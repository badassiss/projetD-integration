package com.projetIntegration;

import com.projetIntegration.services.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class ProjetIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetIntegrationApplication.class, args);
	}

	//@Bean
	CommandLineRunner commandLineRunnerUserDetails(AccountService accountService){
		return args -> {
			accountService.addNewRole("TEACHER");
			accountService.addNewRole("STUDENT");
			accountService.addNewUser("medbadiss@gmail.com","1234","1234",1234,"badiss");

			accountService.addNewUser("aziz@gmail.com","123","123",777,"aziz");
			accountService.addNewUser("med@gmail.com","12345","12345",236,"med");

			accountService.AddRoleToPerson("medbadiss@gmail.com","TEACHER");
			accountService.AddRoleToPerson("aziz@gmail.com","STUDENT");


			accountService.AddRoleToPerson("med@gmail.com","STUDENT");

			accountService.addNewRole("ADMIN");
			accountService.addNewUser("admin@admin.com","admin","admin",0000,"admin");
			accountService.AddRoleToPerson("admin@admin.com","ADMIN");

			accountService.addNewUser("Teacher@tet.com","123","123",0001,"teatch");
			accountService.AddRoleToPerson("Teacher@tet.com","TEACHER");



		};



	}

	@Bean
	PasswordEncoder passwordEncoder(){
		return new BCryptPasswordEncoder();
	}

}
