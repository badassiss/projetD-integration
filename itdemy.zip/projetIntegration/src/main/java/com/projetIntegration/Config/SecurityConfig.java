package com.projetIntegration.Config;


import com.projetIntegration.services.AccountService;
import com.projetIntegration.services.AccountServiceImpl;
import com.projetIntegration.services.UserDetailsServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;

@Configuration @EnableWebSecurity @AllArgsConstructor
public class SecurityConfig {


    private PasswordEncoder passwordEncoder;
    private UserDetailsServiceImpl userDetailsServiceImpl;
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity httpSecurity) throws Exception{
        httpSecurity.authorizeHttpRequests().requestMatchers("/webjars/**").permitAll();
        httpSecurity.authorizeHttpRequests().requestMatchers("/assets/**").permitAll();
        httpSecurity.authorizeHttpRequests().requestMatchers("/css/**").permitAll();
        httpSecurity.authorizeHttpRequests().requestMatchers("/js/**").permitAll();
        httpSecurity.authorizeHttpRequests().requestMatchers("/register").permitAll();
        httpSecurity.authorizeHttpRequests().requestMatchers("/favicon.ico", "/resources/**", "/error").permitAll();



        httpSecurity.formLogin().loginPage("/").loginProcessingUrl("/login").defaultSuccessUrl("/").permitAll();
        httpSecurity.authorizeHttpRequests().requestMatchers("/admin/**").hasRole("ADMIN").and()
                .authorizeHttpRequests().requestMatchers("/StudentUser/**").hasAnyRole("STUDENT","ADMIN","TEACHER").and()

                .authorizeHttpRequests().requestMatchers("/ensig/**").hasAnyRole("TEACHER","ADMIN");
        httpSecurity.authorizeHttpRequests().anyRequest().authenticated();
        httpSecurity.userDetailsService(userDetailsServiceImpl);
        httpSecurity.exceptionHandling().accessDeniedPage("/notAuthorized");
        return httpSecurity.build();
    }
}
