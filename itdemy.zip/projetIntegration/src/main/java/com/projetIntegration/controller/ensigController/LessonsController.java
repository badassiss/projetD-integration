package com.projetIntegration.controller.ensigController;

import com.projetIntegration.entities.Courses;
import com.projetIntegration.entities.Lesson;
import com.projetIntegration.repository.CoursesRepository;
import com.projetIntegration.repository.LessonRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
@AllArgsConstructor
public class LessonsController {

    @Autowired
    private LessonRepository lessonRepository;
    @Autowired
    private CoursesRepository coursesRepository;

    @GetMapping("/ensig/lesson")
    public String lessons(Model model){
        List<Lesson> lessons = lessonRepository.findAll();
        model.addAttribute("lessons",lessons);
        return "/ensig/lessons/lessons";
    }
    @GetMapping("/ensig/lesson/new")
    public String newLesson(Model model){
        Iterable<Courses> courseList = coursesRepository.findAll();
        model.addAttribute("courseList",courseList);
        model.addAttribute("lesson", new Lesson());
        return "/ensig/lessons/create_lesson";
    }
    @PostMapping("/ensig/lesson/save")
    public String saveLesson(Lesson lesson){
        lessonRepository.save(lesson);
        return"redirect:/ensig/lesson";
    }
    @GetMapping("/ensig/lesson/edit/{id}")
    public String EditLesson(@PathVariable Integer id, Model model){
        Lesson lesson = lessonRepository.findById(id).get();
        model.addAttribute("lesson",lesson);
        Iterable<Courses> coursesList = coursesRepository.findAll();
        model.addAttribute("coursesList",coursesList);
        return"/ensig/lessons/create_lesson";
    }
    @GetMapping("/ensig/lesson/delete/{id}")
    public String deleteLesson(@PathVariable Integer id, Model model){
        model.getAttribute("lesson");
        Lesson lessonToDelete = lessonRepository.findById(id).get();
        lessonRepository.delete(lessonToDelete);
        return"redirect:/ensig/lesson";
    }


}
