package com.projetIntegration.controller;

import com.projetIntegration.entities.AppUser;
import com.projetIntegration.entities.Role;
import com.projetIntegration.repository.PersonneRepository;
import com.projetIntegration.repository.RoleRepository;
import com.projetIntegration.services.AccountService;
import lombok.AllArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Arrays;

@Controller
@AllArgsConstructor
public class RegisterController {
private PersonneRepository personneRepository;
private AccountService accountService;
private PasswordEncoder passwordEncoder;
private RoleRepository roleRepository;
    @GetMapping("/register")
    public String showRegistrationForm(Model model){
        AppUser user = new AppUser();
        model.addAttribute("user", user);
        return "/register.html";
    }

    // handler method to handle register user form submit request
    @PostMapping("/register/save")
    public String registration(@Validated @ModelAttribute("user") AppUser user,
                               BindingResult result,
                               Model model){
        AppUser existing = accountService.loadUserByUsername(user.getUsername());
        if (existing != null) {
            result.rejectValue("username", null, "There is already an account registered with that email");
        }
        if (result.hasErrors()) {
            model.addAttribute("user", user);
            return "register";
        }
        user.setPwd(passwordEncoder.encode(user.getPwd()));
        Role role = roleRepository.findByRole("STUDENT");
        user.setRoles(Arrays.asList(role));
        personneRepository.save(user);
        return "redirect:/register?success";
    }



}
