package com.projetIntegration.controller.AdminController;

import com.projetIntegration.entities.AppUser;
import com.projetIntegration.entities.Courses;
import com.projetIntegration.entities.Lesson;
import com.projetIntegration.entities.Test;
import com.projetIntegration.repository.*;
import com.projetIntegration.services.AccountServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
@AllArgsConstructor
public class TestController {

    @Autowired
    private LessonRepository lessonRepository;
    @Autowired
    private CoursesRepository coursesRepository;
    @Autowired
    private TestRepository testRepository;
    @Autowired
    AccountServiceImpl accountService;

    @GetMapping("/admin/test/new")
    public String NewTest(Model model){
        Iterable<Lesson> LessonsList = lessonRepository.findAll();
        Iterable<Courses> CoursesList = coursesRepository.findAll();
        model.addAttribute("test",new Test());
        model.addAttribute("LessonsList",LessonsList);
        model.addAttribute("CoursesList",CoursesList);
        return "/admin/Test/create_test";
    }

    @PostMapping("/Test/test/save")
    public String SaveTest(Test test){
        testRepository.save(test);
        return"redirect:/admin/test";
    }

    @GetMapping("/admin/test")
    public String ListTests(Model model){
        List<Test> TestLists = testRepository.findAll();
        model.addAttribute("tests", TestLists);
        return "/admin/Test/test";
    }

    @GetMapping("/admin/test/edit/{id}")
    public String EditTest(@PathVariable Integer id, Model model){
        Test test=testRepository.findById(id).get();
        model.addAttribute("test",test);
        Iterable<Courses> CoursesList = coursesRepository.findAll();
        Iterable<Lesson> LessonsList = lessonRepository.findAll();
        model.addAttribute("CoursesList",CoursesList);
        model.addAttribute("LessonsList",LessonsList);
        return "/admin/Test/create_test";
    }
    @GetMapping("/admin/test/delete/{id}")
    public String DeleteTest(@PathVariable Integer id, Model model){
        model.getAttribute("test");
        Test DeletedTest = testRepository.findById(id).get();
        testRepository.delete(DeletedTest);
        return"redirect:/admin/test";
    }


}
