package com.projetIntegration.controller.AdminController;

import com.projetIntegration.entities.AppUser;
import com.projetIntegration.entities.Role;
import com.projetIntegration.repository.PersonneRepository;
import com.projetIntegration.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Arrays;
import java.util.List;

@Controller
public class UserController {
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    private PersonneRepository personneRepository;
    @Autowired
    private RoleRepository roleRepository;


    @GetMapping("/")
    public String home(){
        return"/index";
    }


  @GetMapping("/admin/users")
    public String ListUsers(Model model){
      Iterable<AppUser> usersList = personneRepository.findAll();
      model.addAttribute("users", usersList);
              return "/admin/users/users";
  }
  @GetMapping("/admin/users/edit/{Userid}")
    public String editUserForm(@PathVariable Integer Userid,Model model){
      AppUser user = personneRepository.findById(Userid).get();
      model.addAttribute("user",user);
      List<Role> roleList = roleRepository.findAll();
      model.addAttribute("roleList",roleList);
      return"/admin/users/create_user";
  }


    @PostMapping("/users/user/save")
    public String saveUser( AppUser user){
      user.setPwd(passwordEncoder.encode(user.getPwd()));
        personneRepository.save(user);
        return "redirect:/admin/users";
    }

    @GetMapping("/admin/users/new")
    public String createUserForm(Model model){
        List<Role>  roleList = roleRepository.findAll();
        model.addAttribute("user", new AppUser());
        model.addAttribute("roleList",roleList);
        return"/admin/users/create_user";
    }
    @GetMapping("/admin/users/delete/{Userid}")
    public String DeleteStudentForm(@PathVariable Integer Userid, Model model){
        model.getAttribute("user");
        AppUser userDeleted = personneRepository.findById(Userid).get();
        personneRepository.delete(userDeleted);
        return"redirect:/admin/users";
    }

}
