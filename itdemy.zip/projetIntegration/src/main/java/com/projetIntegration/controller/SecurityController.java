package com.projetIntegration.controller;

import com.projetIntegration.repository.PersonneRepository;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@NoArgsConstructor
@Controller
public class SecurityController {

    @Autowired
    private PersonneRepository personneRepository;


    @GetMapping("/login")
    public String login(){
        return "login";
    }
    @GetMapping("/admin/index")
    public String homeAdmin(){
        return"/admin/index";
    }

    @GetMapping("/StudentUser/index")
    public String homeStudent(){
        return"/StudentUser/index";
    }

    @GetMapping("/notAuthorized")
    public String notAuthorized(){
        return "notAuthorized";
    }



}
