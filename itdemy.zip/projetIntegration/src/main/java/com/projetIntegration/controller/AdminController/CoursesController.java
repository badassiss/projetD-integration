package com.projetIntegration.controller.AdminController;

import com.projetIntegration.entities.AppUser;
import com.projetIntegration.entities.Courses;
import com.projetIntegration.entities.Role;
import com.projetIntegration.repository.CoursesRepository;
import com.projetIntegration.repository.PersonneRepository;
import com.projetIntegration.repository.RoleRepository;
import com.projetIntegration.services.AccountServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.security.access.method.P;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@AllArgsConstructor
public class CoursesController {
    @Autowired
    private PersonneRepository personneRepository;
    @Autowired
    private CoursesRepository coursesRepository;
    @Autowired
    private RoleRepository roleRepository;
@Autowired
    AccountServiceImpl accountService;

    @GetMapping("/admin/courses/new")
    public String NewCourse(Model model){
        Iterable<AppUser> TeachersList = personneRepository.findAll();
        model.addAttribute("course",new Courses());
        model.addAttribute("TeachersList",TeachersList);
        return "/admin/courses/create_course";
    }

    @PostMapping("/courses/course/save")
    public String SaveCourse(Courses courses){
        coursesRepository.save(courses);
        return"redirect:/admin/courses";
    }

    @GetMapping("/admin/courses")
    public String ListCourses(Model model){
        List<Courses> CoursesList = coursesRepository.findAll();
        model.addAttribute("courses", CoursesList);
        return "/admin/courses/courses";
    }

    @GetMapping("/admin/courses/edit/{id}")
    public String EditCourse(@PathVariable Integer id, Model model){
        Courses courses=coursesRepository.findById(id).get();
        model.addAttribute("course",courses);
        Iterable<AppUser> TeachersList = personneRepository.findAll();
        model.addAttribute("TeachersList",TeachersList);
    return "/admin/courses/create_course";
    }
    @GetMapping("/admin/courses/delete/{id}")
    public String DeleteStudentForm(@PathVariable Integer id, Model model){
        model.getAttribute("course");
        Courses userDeleted = coursesRepository.findById(id).get();
        coursesRepository.delete(userDeleted);
        return"redirect:/admin/courses";
    }

    }


