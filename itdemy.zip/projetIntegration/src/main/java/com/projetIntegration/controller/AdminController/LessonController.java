package com.projetIntegration.controller.AdminController;

import com.projetIntegration.entities.Courses;
import com.projetIntegration.entities.Lesson;
import com.projetIntegration.repository.CoursesRepository;
import com.projetIntegration.repository.LessonRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.method.P;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@AllArgsConstructor
public class LessonController {

    @Autowired
    private LessonRepository lessonRepository;
    @Autowired
    private CoursesRepository coursesRepository;

    @GetMapping("/admin/lesson")
    public String lessons(Model model){
        List<Lesson> lessons = lessonRepository.findAll();
        model.addAttribute("lessons",lessons);
        return "/admin/lessons/lessons";
    }
    @GetMapping("/admin/lesson/new")
    public String newLesson(Model model){
        Iterable<Courses> courseList = coursesRepository.findAll();
        model.addAttribute("courseList",courseList);
        model.addAttribute("lesson", new Lesson());
        return "/admin/lessons/create_lesson";
    }
    @PostMapping("/admin/lesson/save")
    public String saveLesson(Lesson lesson){
        lessonRepository.save(lesson);
        return"redirect:/admin/lesson";
    }
    @GetMapping("/admin/lesson/edit/{id}")
    public String EditLesson(@PathVariable Integer id, Model model){
        Lesson lesson = lessonRepository.findById(id).get();
        model.addAttribute("lesson",lesson);
        Iterable<Courses> coursesList = coursesRepository.findAll();
        model.addAttribute("coursesList",coursesList);
        return"/admin/lessons/create_lesson";
    }
    @GetMapping("/admin/lesson/delete/{id}")
    public String deleteLesson(@PathVariable Integer id, Model model){
        model.getAttribute("lesson");
        Lesson lessonToDelete = lessonRepository.findById(id).get();
        lessonRepository.delete(lessonToDelete);
        return"redirect:/admin/lesson";
    }
}
