package com.projetIntegration.entities;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class AppUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer Userid;
    @Column(unique = true)
    private String username;
    @Column(unique = true)
    private String pwd;
    @Column(unique = true)
    private int ncin;
    @Column(unique = true)
    private String nom;

    @ManyToMany(fetch = FetchType.EAGER)
    private List<Role> roles;



}
