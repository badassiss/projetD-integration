package com.projetIntegration.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Entity
@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class Test {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String title;
    private String Description;
    private Boolean published;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private Date created_at;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private Date updated_at;
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private Date deleted_at;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "course")
    private Courses  course;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "lesson")
    private Lesson  lesson;
}
