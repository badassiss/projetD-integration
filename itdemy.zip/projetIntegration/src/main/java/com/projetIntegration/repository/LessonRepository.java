package com.projetIntegration.repository;

import com.projetIntegration.entities.Lesson;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LessonRepository extends JpaRepository<Lesson,Integer> {

Lesson findByTitle(String title);
}
