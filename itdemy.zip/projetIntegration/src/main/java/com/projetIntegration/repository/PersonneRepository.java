package com.projetIntegration.repository;

import com.projetIntegration.entities.AppUser;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.InitBinder;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface PersonneRepository extends CrudRepository<AppUser, Integer> {

    AppUser findByUsername(String username);



}
